from django.contrib.sitemaps.tests.basic import *
